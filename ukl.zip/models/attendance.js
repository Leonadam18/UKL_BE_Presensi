'use strict'
const {
  Model, DataTypes
} = require('sequelize')

module.exports = (sequelize) => {
  class Attendance extends Model {
    static associate(models) {
      Attendance.belongsTo(models.User, {
        foreignKey: 'user_id',
        as: 'user'
      })
    }
  }

  Attendance.init(
    {
      user_id: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      date: {
        type: DataTypes.DATEONLY,
        allowNull: false,
      },
      time: {
        type: DataTypes.TIME,
        allowNull: false,
      },
      status: {
        type: DataTypes.ENUM('hadir', 'izin', 'sakit', 'alpa'),
        allowNull: false,
      },
    },
    {
      sequelize,
      modelName: 'Attendance',
    }
  )

  return Attendance
}