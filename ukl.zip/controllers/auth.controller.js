const jwt = require('jsonwebtoken')
const bcrypt = require('bcrypt')
const { User } = require('../models')
exports.login = async (req, res) => {
    const { username, password } = req.body
    const user = await User.findOne({ where: { username } })
  
    if (user && bcrypt.compareSync(password, user.password)) {
      const token = jwt.sign({ id: user.id, role: user.role }, 'secret_key', { expiresIn: '1h' })
      res.json({
        success: true,
        message: 'Login berhasil',
        token
      })
    } else {
      res.status(401).json({
        success: false,
        message: 'Email atau kata sandi tidak valid'
      })
    }
  }  