const bcrypt = require('bcrypt')
const { User } = require('../models')
exports.createUser = async (req, res) => {
  const { name, username, password, role } = req.body
  const hashedPassword = bcrypt.hashSync(password, 10)

  try {
    const user = await User.create({ name: name, username: username, password: hashedPassword, role: role })

    res.json({
      status: "success",
      message: "Pengguna berhasil ditambahkan",
      data: user
    })
  } catch (error) {
    res.status(500).json({
      status: "failure",
      message: "Terjadi kesalahan saat membuat pengguna"
    })
  }
}

exports.updateUser = async (req, res) => {
  const { id } = req.params
  const { name, username, password, role } = req.body
  const hashedPassword = bcrypt.hashSync(password, 10)

  try {
    const user = await User.findByPk(id)
    if (!user) {
      return res.status(404).json({
        status: "failure",
        message: `Pengguna dengan ID ${id} tidak ditemukan`
      })
    }

    user.name = name
    user.username = username
    user.password = hashedPassword
    user.role = role
    await user.save()

    res.json({
      status: "success",
      message: "Pengguna berhasil diubah",
      data: user
    })
  } catch (error) {
    res.status(500).json({
      status: "failure",
      message: "Terjadi kesalahan saat memperbarui pengguna"
    })
  }
}

exports.getUser = async (req, res) => {
  const { id } = req.params

  try {
    const user = await User.findByPk(id)
    if (!user) {
      return res.status(404).json({
        status: "failure",
        message: `Pengguna dengan ID ${id} tidak ditemukan`
      })
    }

    res.json({
      status: "success",
      data: user
    })
  } catch (error) {
    res.status(500).json({
      status: "failure",
      message: "Terjadi kesalahan saat mengambil pengguna"
    })
  }
}

exports.deleteUser = async (req, res) => {
  const { id } = req.params

  try {
    const user = await User.findByPk(id)
    if (!user) {
      return res.status(404).json({
        status: "failure",
        message: `Pengguna dengan ID ${id} tidak ditemukan`
      })
    }

    await user.destroy()
    res.json({
      status: "success",
      message: `Pengguna dengan ID ${id} telah berhasil dihapus`
    })
  } catch (error) {
    res.status(500).json({
      status: "failure",
      message: "Terjadi kesalahan saat menghapus pengguna"
    })
  }
}