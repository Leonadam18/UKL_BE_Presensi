const { Attendance, User, Sequelize } = require('../models');
exports.recordAttendance = async (req, res) => {
    const { user_id, date, time, status } = req.body;
  
    try {
      const attendance = await Attendance.create({ user_id, date, time, status });
      res.json({
        success: true,
        message: 'Attendance has been recorded successfully',
        data: attendance
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'An error occurred while recording attendance'
      });
    }
  };

exports.getAttendanceHistory = async (req, res) => {
    const { user_id } = req.params;
  
    try {
      const history = await Attendance.findAll({ where: { user_id } });
      res.json({
        success: true,
        message: `Attendance history for user ID ${user_id} retrieved successfully`,
        data: history
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'An error occurred while fetching attendance history'
      });
    }
};

exports.getMonthlySummary = async (req, res) => {
  const { user_id } = req.params;
  const { month, year } = req.query;

  if (!month || !year) {
    return res.status(400).json({
      status: 'error',
      message: 'Month and year are required',
    });
  }

  try {
    const startDate = `${year.trim()}-${month.trim()}-01`;
    const endDate = `${year.trim()}-${month.trim()}-31`;

    const summary = await Attendance.findAll({
      where: {
        user_id,
        date: { [Sequelize.Op.between]: [startDate, endDate] },
      },
      attributes: [
        'status',
        [Sequelize.fn('COUNT', Sequelize.col('status')), 'count'],
      ],
      group: ['status'],
    });

    const attendanceSummary = {
      hadir: 0,
      izin: 0,
      sakit: 0,
      alpa: 0,
    };
    
    summary.forEach((record) => {
      const status = record.dataValues.status;
      const count = record.dataValues.count;
      if (attendanceSummary[status] !== undefined) {
        attendanceSummary[status] = count;
      }
    });    

    res.json({
      status: 'success',
      data: {
        user_id: parseInt(user_id, 10),
        month: `${month.trim()}-${year.trim()}`,
        attendance_summary: attendanceSummary,
      },
    });
  } catch (error) {
    console.error('Error fetching monthly summary:', error);
    res.status(500).json({
      status: 'error',
      message: 'An error occurred while fetching monthly summary',
    });
  }
}

exports.analyzeAttendance = async (req, res) => {
    const { startDate, endDate, group_by } = req.body;
  
    try {
      const users = await User.findAll({ where: { role } });
      let totalPresent = 0;
      let totalDays = 0;

      for (let user of users) {
        const attendance = await Attendance.findAll({
          where: {
            user_id: user.id,
            date: { [Op.between]: [startDate, endDate] },
          },
        });
  
        totalPresent += attendance.filter((a) => a.status === 'hadir').length;
        totalDays += attendance.length;
      }

      const attendanceRate = totalDays === 0 ? 0 : (totalPresent / totalDays) * 100;
  
      res.json({
        success: true,
        message: 'Attendance analysis completed successfully',
        data: { group_by, attendanceRate },
      });
    } catch (error) {
      console.error(error);
      res.status(500).json({
        success: false,
        message: 'An error occurred while performing attendance analysis',
      });
    }
};