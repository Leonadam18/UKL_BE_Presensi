const express = require('express')
const { createUser, updateUser, getUser, deleteUser } = require('../controllers/user.controller')
const jwt = require('jsonwebtoken')

const verifyToken = (req, res, next) => {
  const token = req.headers['token']

  if (!token) {
    return res.status(403).json({
      status: "failure",
      message: "Tidak ada token yang diberikan. Akses ditolak."
    });
  }

  try {
    const decoded = jwt.verify(token, 'secret_key')
    req.userId = decoded.id
    req.userRole = decoded.role
    next()
  } catch (error) {
    return res.status(401).json({
      status: "failure",
      message: "Tidak sah! Token tidak valid."
    })
  }
}

const router = express.Router()

router.post('/', verifyToken, createUser)
router.put('/:id', verifyToken, updateUser)
router.get('/:id', verifyToken, getUser)
router.delete('/:id', verifyToken, deleteUser)

module.exports = router