const express = require('express');
const { recordAttendance, getAttendanceHistory, getMonthlySummary, analyzeAttendance } = require('../controllers/attendance.controller');
const jwt = require('jsonwebtoken')

const verifyToken = (req, res, next) => {
  const token = req.headers['token']

  if (!token) {
    return res.status(403).json({
      status: "failure",
      message: "Tidak ada token yang diberikan. Akses ditolak."
    });
  }

  try {
    const decoded = jwt.verify(token, 'secret_key')
    req.userId = decoded.id
    req.userRole = decoded.role
    next()
  } catch (error) {
    return res.status(401).json({
      status: "failure",
      message: "Tidak sah! Token tidak valid."
    })
  }
}

const router = express.Router();

router.post('/', verifyToken, recordAttendance);                         // POST /api/attendance
router.get('/history/:user_id', verifyToken, getAttendanceHistory);       // GET /api/attendance/history/:userId
router.get('/summary/:user_id', verifyToken, getMonthlySummary);          // GET /api/attendance/summary/:userId
router.post('/analysis', verifyToken, analyzeAttendance);                // POST /api/attendance/analysis

module.exports = router;