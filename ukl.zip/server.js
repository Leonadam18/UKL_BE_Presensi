const express = require('express')
const bodyParser = require('body-parser')

const authRoutes = require('./routes/auth.route')
const userRoutes = require('./routes/user.route')
const attendanceRoutes = require('./routes/attendance.route')

const app = express()
app.use(bodyParser.json())

app.use('/api/auth', authRoutes)
app.use('/api/users', userRoutes)
app.use('/api/attendance', attendanceRoutes)

const PORT = 3000
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`))