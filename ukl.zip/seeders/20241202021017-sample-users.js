'use strict'
const bcrypt = require('bcrypt')

module.exports = {
  up: async (queryInterface, Sequelize) => {
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash('12345', saltRounds)

    await queryInterface.bulkInsert('users', [
      {
        name: 'Leon',
        username: 'leenadom',
        password: hashedPassword,
        role: 'siswa',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]);
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete('users', null, {})
  },
}